DS3231.cpp - Arduino/chipKit library support for the DS3231 I2C Real-Time Clock
Copyright (C)2015 Rinky-Dink Electronics, Henning Karlsen. All right reserved
  
This library has been made to easily interface and use the DS3231 RTC with
an Arduino or chipKit.

You can find the latest version of the library at 
http://www.RinkyDinkElectronics.com/

This library is free software; you can redistribute it and/or
modify it under the terms of the CC BY-NC-SA 3.0 license.
Please see the included documents for further information.

Commercial use of this library requires you to buy a license that
will allow commercial use. This includes using the library,
modified or not, as a tool to sell products.

The license applies to all part of the library including the 
examples and tools supplied with the library.  
    
Copyright (C)2015 Rinky-Dink Electronics, Henning Karlsen. All right reserved

** Edited for 12/24 hour format support by Aniket Patra 07/11/2016